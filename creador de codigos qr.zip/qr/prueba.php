<?php
// Incluir la biblioteca PHP QR Code
include('phpqrcode/qrlib.php');

// Directorio temporal donde se guardará el código QR generado
$dir = 'temp/';

// Crear el directorio temporal si no existe
if (!file_exists($dir)) {
    mkdir($dir);
}

// Recibir datos (puedes obtenerlos de un formulario o definirlos manualmente)
$descripcion = isset($_POST['descripcion']) ? $_POST['descripcion'] : 'Galletas chokis';
$fechaCaducidad = isset($_POST['fechadeCaducidad']) ? $_POST['fechadeCaducidad'] : '25 de noviembre de 2025';

// Crear el contenido en formato JSON
$data = array(
    'descripcion' => $descripcion,
    'fechadeCaducidad' => $fechaCaducidad
);

// Convertir el array a JSON
$jsonData = json_encode($data);

// Ruta donde se guardará la imagen del código QR
$filename = $dir . 'qrcode_' . time() . '.png';

// Generar el código QR con el contenido en formato JSON
QRcode::png($jsonData, $filename, QR_ECLEVEL_L, 10);

// Mostrar el QR generado en la página
echo '<h2>Código QR Generado</h2>';
echo '<img src="' . $filename . '" />';

// Proporcionar un enlace para descargar el QR
echo '<p><a href="' . $filename . '" download="qrcode.png">Descargar QR</a></p>';
?>
